let handler = async (m, { conn, command }) => {
    conn.reply(m.chat, `*「 SOURCE CODE SKYBUG 」*

*Cheap Hosting Bot & Servers*
*https://cloud.skyhosting.site/*
`, m)
}

handler.command = /^(sc|sourcecode)$/i

export default handler